@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header"> 
                    <h3>meal</h3>
                </div>

                <div class="card-body">
                    <div class="list-group">
                        
                        <a href="{{route('meals')}}" class="list-group-item list-group-item-action">Display All Meals</a>
                        <a href="{{route('meals.create')}}" class="list-group-item list-group-item-action">Creat New Meal</a>
                        <a href="{{ route('orders') }}" class="list-group-item list-group-item-action">User Order</a>

                      </div>
                </div>
                </div>
            </div>
        

        <div class="col-md-9">
            <div class="card">
                <div class="card-header text-center">           
                    @if (session('message'))
                        <div class="alert alert-success">
                            <h2>{{session('message')}}</h2>
                        </div>
                    @endif
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Description</th>
                            <th scope="col">Category</th>
                            <th scope="col">S.Price</th>
                            <th scope="col">M.Price</th>
                            <th scope="col">L.Price</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                          </tr>
                        </thead>
                        <tbody>
                            @if (count($meals) > 0)
                            @foreach ($meals as $meal)
                            <tr>
                                <th scope="row">{{$loop->iteration}}</th>
                                <td><img src="{{Storage::url($meal->image)}}"  alt="" width="100" height="70"></td>
                                <td>{{$meal->name}}</td>
                                <td>{{$meal->description}}</td>
                                <td>{{$meal->category}}</td>
                                <td>{{$meal->small_meal_price}}</td>
                                <td>{{$meal->medium_meal_price}}</td>
                                <td>{{$meal->large_meal_price}}</td>
                                <td><a href="{{ route('meals.edit', ['id'=>$meal->id]) }}"><i class="fa fa-edit"></i><a></td>
                                    <!--delete code-->
                                <td>
                                    
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal{{$meal->id}}">
                                            <i class="fa fa-trash"></i>
                                          </button>

                                </td>


                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal{{$meal->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    
                                        <form action="{{ route('meals.delete', ['id'=>$meal->id]) }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                  </div>

                                                  <div class="modal-body">
                                                   <h1 class="text-center ">Are You Sure?</h1>
                                                  </div>

                                                  <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-danger"> Delete</button>
                                                  </div>
                                            </div>
                                        </div>
                                    </form>
                                    
                                </div>
                            
                              </tr>
                              @endforeach
                            @else
                            <div class="alert alert-danger text-center">
                                <h2>No Meals To Show</h2>
                            </div>
                            @endif
                         
                        
                        </tbody>
                      </table>
                      {{$meals->links()}}
                </div>
            </div>
        </div>

        
          
          
    </div>
</div>
@endsection
